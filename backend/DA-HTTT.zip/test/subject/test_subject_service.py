from service.SubjectService import SubjectService

subject_service = SubjectService()
